#!/usr/bin/env bash
# Launch the CachyOS Setup Wizard local installer and open it in a browser.
set -e
cd "$(dirname "$0")"
PORT="${PORT:-8787}"
URL="http://127.0.0.1:${PORT}"

if ! command -v node >/dev/null 2>&1; then
  echo "Node.js is required. Install it with:  sudo pacman -S nodejs"
  exit 1
fi

# Cache sudo credentials up front so the install runs without interruption
# (skipped if passwordless sudo or pkexec is already set up).
if command -v sudo >/dev/null 2>&1 && ! sudo -n true 2>/dev/null; then
  echo "Caching sudo credentials for a prompt-free install (Ctrl-C to skip)..."
  sudo -v || true
fi

( sleep 1; xdg-open "$URL" >/dev/null 2>&1 || true ) &
PORT="$PORT" exec node server.js
