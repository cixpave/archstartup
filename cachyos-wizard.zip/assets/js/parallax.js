/*
 * parallax.js
 * Lightweight parallax: background wave layers drift on scroll and react to
 * mouse movement, giving the page depth without any heavy library.
 *
 * Respects prefers-reduced-motion — if the user asked the OS to reduce motion,
 * we leave everything still.
 */

(() => {
  const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const layers = [...document.querySelectorAll("[data-parallax]")];
  if (!layers.length || reduce) return;

  let mouseX = 0, mouseY = 0;
  let scrollY = 0;
  let raf = null;

  function apply() {
    raf = null;
    layers.forEach((layer) => {
      const depth = parseFloat(layer.dataset.parallax) || 0.1;
      const tx = mouseX * depth * 40;          // horizontal drift from mouse
      const ty = scrollY * depth * 0.4 +        // vertical drift from scroll
                 mouseY * depth * 30;           // plus a little from mouse
      layer.style.transform = `translate3d(${tx.toFixed(1)}px, ${ty.toFixed(1)}px, 0)`;
    });
  }

  function schedule() {
    if (raf == null) raf = requestAnimationFrame(apply);
  }

  window.addEventListener(
    "mousemove",
    (e) => {
      // normalize to -0.5..0.5 around the viewport center
      mouseX = e.clientX / window.innerWidth - 0.5;
      mouseY = e.clientY / window.innerHeight - 0.5;
      schedule();
    },
    { passive: true }
  );

  window.addEventListener(
    "scroll",
    () => {
      scrollY = window.scrollY;
      schedule();
    },
    { passive: true }
  );

  apply();
})();
