/*
 * installer.js
 * Front-end half of the live installer. Detects whether the page is being
 * served by the local server (server.js), checks for system updates, and runs
 * the install plan while streaming progress into a UI.
 *
 * When the page is just opened as a file (no server), everything here reports
 * "unavailable" and the wizard falls back to generating a script.
 */

const Installer = (() => {
  const token = document
    .querySelector('meta[name="install-token"]')?.getAttribute("content") || "";
  const declaredServer =
    document.querySelector('meta[name="install-server"]')?.getAttribute("content") === "1";

  let health = null;          // null until /api/health resolves
  const readyCbs = [];

  function onReady(cb) {
    if (health !== null) cb(health);
    else readyCbs.push(cb);
  }

  // Probe the backend. Only meaningful when served over http(s), not file://.
  async function probe() {
    if (!declaredServer || location.protocol === "file:") {
      health = { ok: false };
    } else {
      try {
        const r = await fetch("/api/health", { cache: "no-store" });
        health = r.ok ? await r.json() : { ok: false };
      } catch {
        health = { ok: false };
      }
    }
    readyCbs.splice(0).forEach((cb) => cb(health));
  }

  const available = () => !!(health && health.ok);

  async function checkUpdates() {
    if (!available()) return { available: false };
    try {
      const r = await fetch("/api/check-updates", { headers: { "X-Install-Token": token } });
      return await r.json();
    } catch {
      return { available: false };
    }
  }

  /* Run a plan, streaming NDJSON progress and invoking `on(event)` per event. */
  async function run(plan, on) {
    const res = await fetch("/api/install", {
      method: "POST",
      headers: { "Content-Type": "application/json", "X-Install-Token": token },
      body: JSON.stringify(plan),
    });
    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let buf = "";
    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      buf += decoder.decode(value, { stream: true });
      let nl;
      while ((nl = buf.indexOf("\n")) >= 0) {
        const line = buf.slice(0, nl).trim();
        buf = buf.slice(nl + 1);
        if (line) { try { on(JSON.parse(line)); } catch {} }
      }
    }
  }

  probe();
  return { onReady, available: () => available(), health: () => health, checkUpdates, run };
})();
