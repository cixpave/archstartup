#!/usr/bin/env node
/*
 * server.js — the local installer backend for the CachyOS Setup Wizard.
 *
 * Run this ON the CachyOS machine you want to set up:
 *     node server.js     (then open http://127.0.0.1:8787)
 *
 * Why a server at all? A web page on its own can only *generate* a script — a
 * browser can't run pacman. This tiny server (no npm dependencies) bridges
 * that gap: it serves the wizard AND exposes two local APIs the wizard calls
 * to (a) check for updates and (b) actually run the install, streaming live
 * progress back to the page.
 *
 * Safety:
 *   - Binds to 127.0.0.1 only — never reachable from the network.
 *   - A per-launch token (injected into the page) is required for the install
 *     APIs, so a random website in your browser can't drive it.
 *   - If pacman isn't present (e.g. you're just trying it on another distro)
 *     it runs in DRY-RUN: it simulates the install so the UI still works.
 */

const http = require("http");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const { spawn, execSync } = require("child_process");

const ROOT = __dirname;
const PORT = parseInt(process.env.PORT || "8787", 10);
const HOST = "127.0.0.1";
const TOKEN = crypto.randomBytes(16).toString("hex");

// ---- Environment probe -----------------------------------------------------
function has(cmd) {
  try { execSync(`command -v ${cmd}`, { stdio: "ignore" }); return true; }
  catch { return false; }
}
const HAS_PACMAN = has("pacman");
const HAS_PKEXEC = has("pkexec");
function sudoMode() {
  if (!has("sudo")) return "none";
  try { execSync("sudo -n true", { stdio: "ignore" }); return "passwordless"; }
  catch { return "password"; }
}

const MIME = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".svg": "image/svg+xml",
  ".json": "application/json; charset=utf-8",
  ".sh": "text/x-shellscript; charset=utf-8",
};

// ---- Static file serving ---------------------------------------------------
function serveStatic(req, res) {
  let urlPath = decodeURIComponent(req.url.split("?")[0]);
  if (urlPath === "/") urlPath = "/index.html";

  // Resolve safely inside ROOT (no path traversal).
  const filePath = path.normalize(path.join(ROOT, urlPath));
  if (!filePath.startsWith(ROOT)) { res.writeHead(403).end("Forbidden"); return; }

  fs.readFile(filePath, (err, data) => {
    if (err) { res.writeHead(404).end("Not found"); return; }
    const ext = path.extname(filePath);
    // Inject the install token + a flag into index.html so the front-end knows
    // it's running under the server (not just opened as a file).
    if (ext === ".html") {
      const meta =
        `<meta name="install-token" content="${TOKEN}" />\n` +
        `<meta name="install-server" content="1" />`;
      data = Buffer.from(data.toString().replace("</head>", meta + "\n</head>"));
    }
    res.writeHead(200, { "Content-Type": MIME[ext] || "application/octet-stream" });
    res.end(data);
  });
}

// ---- Helpers ---------------------------------------------------------------
function readBody(req) {
  return new Promise((resolve) => {
    let b = "";
    req.on("data", (c) => (b += c));
    req.on("end", () => { try { resolve(JSON.parse(b || "{}")); } catch { resolve({}); } });
  });
}
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
function authed(req) { return req.headers["x-install-token"] === TOKEN; }

// Rewrite privilege escalation so the install can run without a terminal:
// if passwordless sudo isn't available but pkexec (graphical prompt) is, use it.
function escalate(cmd, isAur, mode) {
  if (mode === "passwordless" || mode === "none") return cmd;
  if (!HAS_PKEXEC) return cmd; // will prompt in the launching terminal
  let c = cmd.replace(/\bsudo\b/g, "pkexec");
  if (isAur && /\bparu\b/.test(c)) c = c.replace(/\bparu\b/, "paru --sudo pkexec");
  return c;
}

// ---- /api/check-updates ----------------------------------------------------
async function checkUpdates(res) {
  if (!HAS_PACMAN) {
    return sendJSON(res, { available: false, reason: "pacman not found (not an Arch system)" });
  }
  // `checkupdates` (from pacman-contrib) is the safe way; fall back to pacman -Qu.
  const cmd = has("checkupdates")
    ? "checkupdates"
    : "pacman -Qu 2>/dev/null";
  const child = spawn("bash", ["-lc", cmd]);
  let out = "";
  child.stdout.on("data", (d) => (out += d));
  child.on("close", () => {
    const pkgs = out.split("\n").map((l) => l.trim()).filter(Boolean);
    sendJSON(res, { available: true, count: pkgs.length, packages: pkgs.slice(0, 50) });
  });
  child.on("error", () => sendJSON(res, { available: false, reason: "could not check" }));
}

function sendJSON(res, obj) {
  res.writeHead(200, { "Content-Type": "application/json" });
  res.end(JSON.stringify(obj));
}

// ---- /api/install (streams NDJSON progress) --------------------------------
async function install(req, res) {
  const body = await readBody(req);
  const steps = Array.isArray(body.steps) ? body.steps : [];
  const dryRun = body.dryRun || !HAS_PACMAN;
  const mode = sudoMode();

  res.writeHead(200, {
    "Content-Type": "application/x-ndjson",
    "Cache-Control": "no-cache",
    "Connection": "keep-alive",
  });
  const emit = (obj) => res.write(JSON.stringify(obj) + "\n");

  emit({ type: "start", total: steps.length, dryRun, sudo: mode });

  let completed = 0;
  let failed = false;

  for (let i = 0; i < steps.length; i++) {
    const step = steps[i];
    emit({ type: "step", index: i, label: step.label, status: "running" });

    let stepFailed = false;
    for (const rawCmd of step.commands || []) {
      const cmd = dryRun ? rawCmd : escalate(rawCmd, step.aur, mode);
      emit({ type: "log", line: `$ ${cmd}` });

      if (dryRun) {
        // Simulate a realistic download/install with a moving percentage.
        const name = (step.label || "package").toLowerCase();
        for (let pct = 0; pct <= 100; pct += 20) {
          emit({ type: "log", line: `  downloading ${name}... ${pct}%`, sub: pct });
          await sleep(90);
        }
        emit({ type: "log", line: `  installing ${name}... done` });
        await sleep(120);
      } else {
        const code = await runStreaming(cmd, emit);
        if (code !== 0) { stepFailed = true; break; }
      }
    }

    if (stepFailed) {
      failed = true;
      emit({ type: "step", index: i, status: "error" });
      emit({ type: "log", line: `  ✗ "${step.label}" failed — continuing with the rest.` });
    } else {
      completed++;
      emit({ type: "step", index: i, status: "done" });
    }
    emit({ type: "progress", percent: Math.round(((i + 1) / steps.length) * 100) });
  }

  emit({ type: "done", completed, total: steps.length, failed, reboot: !!body.reboot, dryRun });
  res.end();
}

function runStreaming(cmd, emit) {
  return new Promise((resolve) => {
    const child = spawn("bash", ["-lc", cmd], { env: process.env });
    const onData = (buf) =>
      buf.toString().split("\n").forEach((l) => { if (l.trim()) emit({ type: "log", line: l }); });
    child.stdout.on("data", onData);
    child.stderr.on("data", onData);
    child.on("error", (e) => { emit({ type: "log", line: `  error: ${e.message}` }); resolve(1); });
    child.on("close", (code) => resolve(code == null ? 1 : code));
  });
}

// ---- Router ----------------------------------------------------------------
const server = http.createServer(async (req, res) => {
  const url = req.url.split("?")[0];

  if (url === "/api/health") {
    return sendJSON(res, {
      ok: true, pacman: HAS_PACMAN, pkexec: HAS_PKEXEC,
      sudo: sudoMode(), platform: process.platform,
    });
  }
  if (url === "/api/check-updates") {
    if (!authed(req)) { res.writeHead(401).end("bad token"); return; }
    return checkUpdates(res);
  }
  if (url === "/api/install" && req.method === "POST") {
    if (!authed(req)) { res.writeHead(401).end("bad token"); return; }
    return install(req, res);
  }
  if (url.startsWith("/api/")) { res.writeHead(404).end("no such api"); return; }

  return serveStatic(req, res);
});

server.listen(PORT, HOST, () => {
  const line = "─".repeat(54);
  console.log(`\n  ${line}`);
  console.log(`   CachyOS Setup Wizard — local installer`);
  console.log(`  ${line}`);
  console.log(`   Open:   http://${HOST}:${PORT}`);
  console.log(`   pacman: ${HAS_PACMAN ? "yes" : "no (DRY-RUN — installs are simulated)"}`);
  console.log(`   sudo:   ${sudoMode()}${HAS_PKEXEC ? " · pkexec available" : ""}`);
  if (HAS_PACMAN && sudoMode() === "password" && !HAS_PKEXEC) {
    console.log(`   tip:    run 'sudo -v' first (or enable NOPASSWD) for a prompt-free install.`);
  }
  console.log(`  ${line}\n`);
});
